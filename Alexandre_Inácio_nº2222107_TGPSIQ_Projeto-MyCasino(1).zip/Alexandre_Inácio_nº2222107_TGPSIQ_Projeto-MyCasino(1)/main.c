#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <conio.c>
#include <windows.h>
#include <string.h>
#include "menu.h"
#include <locale.h>
#include "user.h"
#include "casino.h"
#include "slotmachine.h"



int main() {
    setlocale(LC_ALL, "portuguese");
    int e, i, l, e1 = 0, contador = 0;
    char nome[24], nome2[24], nome3[24],pass[20], pass2[20];

    do {
        system("cls");
        printf(R"EOF(


___  ___        _____           _
|  \/  |       /  __ \         (_)
| .  . |_   _  | /  \/ __ _ ___ _ _ __   ___
| |\/| | | | | | |    / _` / __| | '_ \ / _ \
| |  | | |_| | | \__/\ (_| \__ \ | | | | (_) |
\_|  |_/\__, |  \____/\__,_|___/_|_| |_|\___/
         __/ |
        |___/
 __    _                 _         _____   ______           _     _
/  | _| |               (_)       / __  \ _| ___ \         (_)   | |
`| |(_) |     ___   __ _ _ _ __   `' / /'(_) |_/ /___  __ _ _ ___| |_ __ _ _ __
 | |  | |    / _ \ / _` | | '_ \    / /    |    // _ \/ _` | / __| __/ _` | '__|
_| |__| |___| (_) | (_| | | | | | ./ /___ _| |\ \  __/ (_| | \__ \ || (_| | |
\___(_)_____/\___/ \__, |_|_| |_| \_____/(_)_| \_\___|\__, |_|___/\__\__,_|_|
                    __/ |                              __/ |
                   |___/                              |___/


)EOF");
        fflush(stdin);

        FILE *login;
        login = fopen("login.txt", "a+");


        printf("Resposta: ");
        scanf("%i", &e);
        fflush(stdin);

        switch (e) {
            case 1:
                fopen("login.txt", "a+");
                printf("\nNome: ");
                printf("\nPassword: ");
                gotoxy(6, 24);
                scanf("%s", nome);

                gotoxy(10, 25);
                i = 0;
                while ((pass[i] = getch()) != '\r') {
                    printf("*");
                    i++;
                }
                pass[i] = '\0';

                while (fscanf(login, "%s %s", nome2, pass2) != EOF) {
                    if (strcmp(pass, pass2) == 0 && strcmp(nome, nome2) == 0) {
                        contador++;
                        fclose(login);
                    }
                }

                if (contador == 1) {
                    e1 = 1;
                    printf("\nBem vindo %s\n", nome);
                    system("pause");
                    system("cls");
                } else {
                    printf("\nPassword ou Usu�rio incorretos\n");
                    system("pause");
                    system("cls");
                }
                break;

            case 2:printf("O nome nem a palavra pass podem conter espa�os\n");
                fopen("login.txt", "a+");
                printf("\nNome: \n");
                gotoxy(6, 25);
                gets(nome);
                int contemEspacos = 0;

                for (int i = 0; nome[i] != '\0'; i++) {
                if (nome[i] == ' ') {
                contemEspacos = 1;
                break;}
                }
                if (contemEspacos) {
                printf("O nome n�o pode conter espa�os\n");
                system("pause");
                fclose(login);
                break;
                }



                while (fscanf(login, "%s", nome3) != EOF) {
                    if (strcmp(nome3, nome) == 0) {
                        printf("Esse usu�rio j� existe\nTente utilizar outro\n");
                        e1 = 3;
                        system("pause");
                        break;
                    } else {
                        e1 = 2;
                    }
                }

                if (e1 == 3) {
                    e1 = 3;
                    continue;
                }

                gotoxy(10, 25);
                i = 0;
            printf("\nPassword:");
                while ((pass[i] = getch()) != '\r') {
            printf("*");
            i++;
        }
        pass[i] = '\0';
        int contemEspacosSenha = 0;
            for (int j = 0; pass[j] != '\0'; j++) {
        if (pass[j] == ' ') {
        contemEspacosSenha = 1;
        break;
            }
        }

            if (contemEspacosSenha) {
            printf("\nA senha n�o pode conter espa�os\n");
            system("pause");
            fclose(login);
            break;
        }

        printf("\nConfirmar Password: ");
        i = 0;
        while ((pass2[i] = getch()) != '\r') {
            printf("*");
            i++;
        }
        pass2[i] = '\0';
         int contemEspacosSenha2 = 0;
        for (int k = 0; pass2[k] != '\0'; k++) {
        if (pass2[k] == ' ') {
        contemEspacosSenha2 = 1;
        break;
                }
            }

                if (contemEspacosSenha2) {
                printf("\nA confirma��o de senha n�o pode conter espa�os\n");
                system("pause");
                fclose(login);
                break;
                }

                 else {
                    fprintf(login, "\n%s %s", nome, pass);
                    printf("\nAs senhas foram registradas com sucesso\n");
                    system("pause");
                    strcpy(nome2, nome);
                    strcat(nome, ".txt");
                    FILE *nomelog;
                    nomelog = fopen(nome, "a+");
                    fprintf(nomelog, "100 \n0 \n0 \n");
                    fclose(nomelog);
                    fclose(login);
                    e1 = 2;
                    break;
                }

            case 3:
                e1 = 1;
                system("cls");
                break;
        }
    } while (e1 != 1);

    menu(nome);

    return 0;
}


