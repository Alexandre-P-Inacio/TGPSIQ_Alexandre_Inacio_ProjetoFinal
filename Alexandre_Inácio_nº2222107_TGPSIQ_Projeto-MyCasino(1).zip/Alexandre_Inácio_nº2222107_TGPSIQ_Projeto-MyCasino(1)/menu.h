#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#include "codigos.h"

struct user{
    char nome[25];
    float dinheiro;
    int npenalizacoes;
    int jganhos;
}user;


    void menu(char nome[25]) {
        system("cls");
        strcpy(user.nome,nome);
    strcat(nome, ".txt");
    FILE* nome1;
    nome1 = fopen(nome, "a+");
    fscanf(nome1, "%f\n%i\n%i", &user.dinheiro, &user.jganhos, &user.npenalizacoes);
    char palavra[100];

    int e = 0;
    FILE* sobrenos;
    sobrenos = fopen("sobrenos.txt", "r");
    keybd_event(VK_MENU, 0x36, 0, 0);
    keybd_event(VK_RETURN, 0x1C, 0, 0);
    keybd_event(VK_RETURN, 0x1C, KEYEVENTF_KEYUP, 0);
    keybd_event(VK_MENU, 0x38, KEYEVENTF_KEYUP, 0);

    do {
        gotoxy(20, 10);
        printf("\t\t\t|||||||||||||||||||||||||||||||\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         1-Come�ar           |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         2-Estatisticas user |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         3-Regras            |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         4-Sobre n�s         |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         5-C�digos           |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|         6-Sair              |\n");
        printf("\t\t\t\t\t|                             |\n");
        printf("\t\t\t\t\t|||||||||||||||||||||||||||||||\n");

        scanf("%i", &e);
        fflush(stdin);
        switch (e) {
            case 1:
                casino1(nome);
                break;
            case 2:
                stats(user.nome, &user.dinheiro, user.jganhos, user.npenalizacoes);
                e = 1;
                break;
            case 3:
                system("cls");
                printf(R"EOF(
 ____     ___   ____  ____    ____  _____
|    \   /  _] /    ||    \  /    |/ ___/
|  D  ) /  [_ |   __||  D  )|  o  (   \_
|    / |    _]|  |  ||    / |     |\__  |
|    \ |   [_ |  |_ ||    \ |  _  |/  \ |
|  .  \|     ||     ||  .  \|  |  |\    |
|__|\_||_____||___,_||__|\_||__|__| \___|  )EOF");

                textcolor(RED);

                printf(R"EOF(


  _____               _ _                                                                                  /\/|                 _ _                       _           _
 | ____|___  ___ ___ | | |__   ___ _ __   ___  ___ _ __ ___  _ __  _ __ ___    __ _ ___    ___  _ __   ___|/\/   ___  ___    __| (_)___ _ __   ___  _ __ (_)_   _____(_)___
 |  _| / __|/ __/ _ \| | '_ \ / _ \ '__| / __|/ _ \ '_ ` _ \| '_ \| '__/ _ \  / _` / __|  / _ \| '_ \ / __/ _ \ / _ \/ __|  / _` | / __| '_ \ / _ \| '_ \| \ \ / / _ \ / __|
 | |___\__ \ (_| (_) | | | | |  __/ |    \__ \  __/ | | | | | |_) | | |  __/ | (_| \__ \ | (_) | |_) | (_| (_) |  __/\__ \ | (_| | \__ \ |_) | (_) | | | | |\ V /  __/ \__ \
 |_____|___/\___\___/|_|_| |_|\___|_|    |___/\___|_| |_| |_| .__/|_|  \___|  \__,_|___/  \___/| .__/ \___\___/ \___||___/  \__,_|_|___/ .__/ \___/|_| |_|_| \_/ \___|_|___/
                                                            |_|                                |_|     )_)                             |_|


         (N�o seguir a regra resultar� em um punimento)
)EOF");
                textcolor(WHITE);
                system("pause");
                system("cls");
                break;
            case 4:
                system("cls");
                while (fgets(palavra, sizeof(palavra), sobrenos) != NULL) {
                    printf("%s", palavra);
                }
                system("pause");
                system("cls");
                break;
            case 5: codigos(nome,user.dinheiro,user.jganhos, user.npenalizacoes);break;

            case 6:
                return 0;
        }
    } while (e != 6);

    return 0;
}



#endif // MENU_H_INCLUDED
