#ifndef ROLETA_H_INCLUDED
#define ROLETA_H_INCLUDED
#include "imagem.h"

float roleta(char* nome,float din,int jganhos,int npenalizacoes) {
        int numeroSorteado, e;
    int naposta, res;
    float aposta, ganho;
    setlocale(LC_ALL,"Portuguese");
    system("cls");
    gotoxy(25,22);
     srand(time(NULL));
     do{
     do{
            system("cls");
      numeroSorteado = rand() % 36;

    printf(R"EOF(

                                 __________       .__          __
                                 \______   \ ____ |  |   _____/  |______
                                  |       _//  _ \|  | _/ __ \   __\__  \
                                  |    |   (  <_> )  |_\  ___/|  |  / __ \_
                                  |____|_  /\____/|____/\___  >__| (____  /
                                         \/                 \/          \/

                   )EOF");

  printf("=======================================================================================");
  printf("\n\n\t\t\tQuanto voc� deseja apostar?                                       Saldo:$%.2f\n", din);
  printf("\t\t\t\t");
    if (scanf("%f", &aposta) != 1) {
                    fflush(stdin);
                    npenalizacoes=npenalizacoes+1;
                din=din-10;
                    continue;  // Reinicia o programa se o valor digitado n�o for um n�mero
                }
                if(aposta>din)
    {
        printf("Saldo insuficiente\n");
        e=2;
        system("pause");
        system("cls");
        continue;

    }
    else{e=1;}

    }while(e!=1);
        system("cls");
    imagem();
               printf("\t1-N�mero\t2-1st 12\n\t\t\t3-2nd 12\t4-3rd 12\n\t\t\t5-1 para 18\t6-19 para 36\n\t\t\t7-Impar\t\t8-Par\n\t\t\t9-Sair\n\t\t\tResposta:");

                if (scanf("%i", &e) != 1) {
                    fflush(stdin);
                    npenalizacoes=npenalizacoes+1;
                    din=din-10;
                    continue;  // Reinicia o programa se o valor digitado n�o for um n�mero
                }
                if(e==1)
                {

                   printf("\t\t\t\t\tQue n�mero deseja apostar?\n");
                   if (scanf("%i", &naposta) != 1) {
                    fflush(stdin);
                    npenalizacoes=npenalizacoes+1;
                    din=din-10;
                    continue;  // Reinicia o programa se o valor digitado n�o for um n�mero
                }
                }
                if(e!=9){



                srand(time(NULL));

                int i2;
                do{
                i2 = rand() % 10;
                }while(i2==0);

                system("cls");
                imagem();
                float cont=0.7;
                for(int i=0;i<i2;i++){
                        if(numeroSorteado>36){
                            numeroSorteado=0;
                        }

                        printf("%i | ",numeroSorteado);
                        cont=cont+0.2;
                        sleep(cont);
                        numeroSorteado=numeroSorteado+1;
                }
                }

                switch (e)
                {
                    case 1: if(naposta==numeroSorteado)
                    {
                        ganho=aposta*35;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tSaldo:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    } else{ din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);

                    }break;

                    case 2: if(12<=numeroSorteado && 1>=numeroSorteado){
                        ganho=aposta*1.3;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    }
                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);
                    }
                        break;

                    case 3:if(24<=numeroSorteado && 13>=numeroSorteado){
                        ganho=aposta*1.3;
                        printf("\n\t\t\tPARABENS!!\n\t\t\Ganhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    }
                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);
                    }break;

                    case 4:if(36<=numeroSorteado && 25>=numeroSorteado){
                        ganho=aposta*1.3;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    }
                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);}break;

                    case 5:if(1<=numeroSorteado && 18>=numeroSorteado){
                        ganho=aposta*1.1;
                        printf("\n\t\t\tPARABENS!!\n\t\t\ttGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    }
                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);}
                    break;

                    case 6:if(19<=numeroSorteado && 36>=numeroSorteado){
                        ganho=aposta*1.1;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                    }
                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);}break;

                    case 7: if(numeroSorteado %2==0){
                        ganho=aposta*1.1;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;jganhos=jganhos+1;}

                    else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);}break;
                    case 8:if(numeroSorteado%2==1){
                        ganho=aposta*1.1;
                        printf("\n\t\t\tPARABENS!!\n\t\t\tGanhou:%.2f",ganho);
                        din=din+ganho;jganhos=jganhos+1;
                            }
                            else{   din=din-aposta;
                        printf("\n\t\t\tQue Azar, boa sorte para a pr�xima\n\t\t\tSaldo:%.2f",din);}break;
                    case 9: return 0;

                    default: printf("Digito incorreto\n");
                    npenalizacoes=npenalizacoes+1;
                    din=din-10;
                    continue;

                }
                printf("\n");
                system("pause");
                }while(e!=9);

                FILE *nome1;
        printf("%f\n%i\n%i",din,jganhos,npenalizacoes);
        nome1= fopen(nome, "w+");
        fprintf(nome1,"%f\n%i\n%i",din, jganhos, npenalizacoes);
        fclose(nome1);
}
#endif // ROLETA_H_INCLUDED
