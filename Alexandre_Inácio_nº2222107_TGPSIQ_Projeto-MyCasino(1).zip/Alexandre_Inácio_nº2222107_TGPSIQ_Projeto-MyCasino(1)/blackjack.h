#ifndef BLACKJACK_H_INCLUDED
#define BLACKJACK_H_INCLUDED
#include "naipes.h"
#include "image1.h"


struct cartas {
    char carta1, carta2, carta3, carta4, carta5;
    int naipe1, naipe2, naipe3, naipe4, naipe5;
    int valor1, valor2, valor3, valor4, valor5;
} cartas;

    void blackjack(char* nome, float din, int npenalizacoes, int jganhos ) {
    int e;
    char carta[] = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'};
    int naipe[] = {'1', '2', '3', '4'};
    int res;
    int total = 0;
    float aposta;
    system("cls");
    gotoxy(25,22);
    printf(R"EOF(    ================================================================================================================
                            1-O objetivo do jogo � obter uma m�o com um valor total mais pr�ximo poss�vel de 21, sem ultrapassar esse valor.

                            2-O jogo � jogado com um baralho padr�o de 52 cartas. Os valores das cartas s�o os seguintes: cartas num�ricas
                            de 2 a 10 valem seu valor nominal,as cartas de figura (valete, dama ,rei e �s) valem 10 pontos cada.

                            3-As cartas s�o distribuidas aleat�riamente
                            ================================================================================================================
                 )EOF");system("pause");system("cls");
    do {
        do {
            e = 0;
            res = 0;
            total = 0;
            aposta = 0;
            system("cls");
            aposta = 0;
            image1();
            printf("\n\tQuanto voc� deseja apostar?                                       Saldo:$%.2f\n", din);
            gotoxy(38,11);
            fflush(stdin);
            if (scanf("%f", &aposta) != 1) {
                printf("Aposta inv�lida. Digite um valor num�rico.\n");
                e = 2;
                npenalizacoes=npenalizacoes+1;
                din=din-10;
                system("pause");
                system("cls");
            } else if (aposta > din) {
                printf("Saldo insuficiente\n");
                e = 2;
                system("pause");
                system("cls");
            } else if (aposta <= din) {
                e = 1;
            }
        } while (e != 1);

        system("cls");
        din = din - aposta;
        image1();
        printf("Suas cartas:\n");

        srand(time(NULL));
        do {
            cartas.carta1 = carta[rand() % 13];
            cartas.carta2 = carta[rand() % 13];
        } while (cartas.carta1 == '0' || cartas.carta2 == '0');
        cartas.naipe1 = naipe[rand() % 3];
        cartas.naipe2 = naipe[rand() % 3];

        cartas.valor1 = naipes(cartas.carta1, cartas.naipe1);
        cartas.valor2 = naipes(cartas.carta2, cartas.naipe2);
        total = cartas.valor1 + cartas.valor2;

        printf("\nPontos: %i", total);
        if (total > 21) {
            printf("\nVoc� perdeu\n");
        } else {
            printf("\nDeseja continuar? \n1 - Sim\n2 - N�o\nResposta: ");
            if (scanf("%i", &res) != 1) {
                din=din-10;
                    npenalizacoes=npenalizacoes+1;
                fflush(stdin);

                continue;  // Reinicia o programa se o valor digitado n�o for um n�mero
            }
            fflush(stdin);
        }

        while (res == 1 && total <= 21) {
            system("cls");
            image1();
            cartas.valor1 = naipes(cartas.carta1, cartas.naipe1);
            cartas.valor2 = naipes(cartas.carta2, cartas.naipe2);
            srand(time(NULL));
            do {
                cartas.carta3 = carta[rand() % 13];
            } while (cartas.carta3 == '0');

            cartas.naipe3 = naipe[rand() % 3];
            cartas.valor3 = naipes(cartas.carta3, cartas.naipe3);
            total = total + cartas.valor3;
            printf("\nPontos: %i", total);
            if (total > 21) {
                printf("\nVoc� perdeu\n");
            } else {
                printf("\nDeseja continuar? \n1 - Sim\n2 - N�o\nResposta: ");
                if (scanf("%i", &res) != 1) {
                    fflush(stdin);
                    npenalizacoes=npenalizacoes+1;
                    din=din-10;
                    continue;  // Reinicia o programa se o valor digitado n�o for um n�mero
                }
                fflush(stdin);
            }
        }

        if (total <= 21) {
            if (total == 21) {
                din = din + aposta + aposta;
            } else if (total == 20) {
                din = din + aposta + aposta * 0.7;
            } else if (total == 19) {
                din = din + aposta + aposta * 0.5;
            } else if (total == 18) {
                din = din + aposta + aposta * 0.3;
            } else if (total < 18) {
                din = din + aposta + aposta * 0.01;
            }
            jganhos=jganhos+1;
            printf("PARAB�NS!!! Voc� ganhou Saldo:%.2f\n", din);
        }

        printf("\nDeseja continuar?\n1 - Sim\n2 - N�o\nResposta: ");
        if (scanf("%i", &res) != 1) {
            fflush(stdin);
            npenalizacoes=npenalizacoes+1;
            din=din-10;
            res = 2;  // Sai do loop se o valor digitado n�o for um n�mero
        }
        fflush(stdin);
    } while (res != 2);
        FILE *nome1;
        printf("%f\n%i\n%i",din,jganhos,npenalizacoes);
        nome1= fopen(nome, "w+");
        fprintf(nome1,"%f\n%i\n%i",din, jganhos, npenalizacoes);
        fclose(nome1);
}

#endif // BLACKJACK_H_INCLUDED
