#ifndef USER_H_INCLUDED
#define USER_H_INCLUDED

  void stats(char* nome,float* dinheiro, int jganhos,int npen)
  {

      float dinheiro2;
      system("cls");
    printf("**********************************************************************\n");
    printf("\n\t\t\t         Nome: %s            \n", nome);

    printf("\n\t\t\t         Dinheiro: %.2f        \n", *dinheiro);

    printf("\n\t\t\t         Profit: ");
    dinheiro2=*dinheiro-100;

    if(dinheiro2<0)
    {
        textcolor(RED);
    }
    else if(dinheiro2 > 0)
    {
        textcolor(GREEN);
    }

    printf("%.2f\n", dinheiro2);
    textcolor(WHITE);

    printf("\n\t\t\t         Jogos ganhos: %i          \n", jganhos);
    printf("\n\t\t\t         N penaliza��es: %i    \n", npen);

    printf("************************************************************************\n");

    system("pause");
    system("cls");
  }

#endif // USER_H_INCLUDED
