#ifndef SLOTMACHINE_H_INCLUDED
#define SLOTMACHINE_H_INCLUDED

void slotmachin(char* nome,int npenalizacoes, int jganhos){
    system("cls");
    int num1,num2,num3;
    float aposta;
    int e;
    int res;

    float din;
    FILE* nome1;
    nome1=fopen(nome,("r"));
    fscanf(nome1,"%f",&din);
    do{
    do{ system("cls");
            imgslot();
       printf("\n\t\tAposta:\t\t\t\t\t\t\t\tDinheiro: $%.2f \n",din);
            gotoxy(24,12);
            fflush(stdin);

            if (scanf("%f", &aposta) != 1) {
                printf("Aposta inv�lida. Digite um valor num�rico.\n");
                e = 2;
                npenalizacoes=npenalizacoes+1;
                din=din-10;
                system("pause");
                system("cls");
            } else if (aposta > din) {
                printf("Saldo insuficiente\n");
                e = 2;
                system("pause");
                system("cls");
            } else if (aposta <= din) {
                e = 1;
            } else {
                e = 1;
            }
        }while(e!=1);

        din=din-aposta;
        system("cls");
        int i;
        for(i=0; i<14; i++){
            srand(time(NULL));
            do{
            num1=rand() % 10;
            num2=rand() % 10;
            num3=rand() % 10;
            }while(num1==0 || num2==0 || num3==0);
            slotimg(num1,num2,num3);
            sleep(1);
        }
        if(num1==num2==num3)
        {
            printf("MUITOS PARABENS!!!! Voc� ganhou o jackpot de 200$\n");
            din=din+aposta+200;
        }
        else if(num1==num2 || num1==num3 || num2==num3)
        {
            din=din+aposta+aposta*0.5;
            printf("PARABENS!!! Voc� ganhou %0.2f\n",aposta*0.5);
        }
        else{printf("QUE AZAR|| Boa sorte para a proxima\n");}

        printf("Deseja continuar?\n1-Sim\n2-N�o\n");
        if (scanf("%i", &res) != 1) {
            fflush(stdin);
            npenalizacoes=npenalizacoes+1;
            din=din-10;
              // Sai do loop se o valor digitado n�o for um n�mero
        }
        if(res==2)
        {
            res = 2;
        }
        else{res ==1;}

        }while(res !=2);

        printf("%f\n%i\n%i",din,jganhos,npenalizacoes);
        nome1= fopen(nome, "w+");
        fprintf(nome1,"%f\n%i\n%i",din, jganhos, npenalizacoes);
        fclose(nome1);

}



void slotimg(num1,num2,num3){

system("cls");
    printf("              .-------.\n");
    printf("              |Jackpot|\n");
    printf("  ____________|_______|____________\n");
    printf(" |  __    __    ___  _____   __    |\n");
    printf(" | / _\\  / /   /___\\/__   \\ / _\\   |\n");
    printf(" | \\ \\  / /   //  //  / /\\ \\\\ \\  []|\n");
    printf(" | _\\ \\/ /___/ \\_//  / /  \\/_\\ \\ []|\n");
    printf(" | \\__/\\____/\\___/   \\/     \\__/ []|\n");
    printf(" |===_______===_______===_______===| __\n");
    printf(" |===_______===_______===_______===|(__)\n");
    printf(" ||*| _____ |*| _____ |*| _____ |*|| ||\n");
    printf(" ||*||     ||*||     ||*||     ||*|| ||\n");
    printf(" ||*||  %i  ||*||  %i  ||*||  %i  ||*|| ||\n", num1,num2,num3);
    printf(" ||*||_____||*||_____||*||_____||*|| ||\n");
    printf(" ||*|_______|*|_______|*|_______|*||_//\n");
    printf(" |===_______===_______===_______===|_/\n");
    printf(" |===___________________________===|\n");
    printf(" |  /___________________________\\  |\n");
    printf(" |   |                         |   |\n");
    printf(" |    \\_______________________/    |_\n");
    printf("(_____________________________________)\n");
}

void imgslot(){
printf(R"EOF(

                  .-')                           .-') _          _   .-')      ('-.                ('-. .-.              .-') _   ('-.
                 ( OO ).                        (  OO) )        ( '.( OO )_   ( OO ).-.           ( OO )  /             ( OO ) )_(  OO)
                (_)---\_) ,--.      .-'),-----. /     '._        ,--.   ,--.) / . --. /   .-----. ,--. ,--.  ,-.-') ,--./ ,--,'(,------.
                /    _ |  |  |.-') ( OO'  .-.  '|'--...__)       |   `.'   |  | \-.  \   '  .--./ |  | |  |  |  |OO)|   \ |  |\ |  .---'
                \  :` `.  |  | OO )/   |  | |  |'--.  .--'       |         |.-'-'  |  |  |  |('-. |   .|  |  |  |  \|    \|  | )|  |
                 '..`''.) |  |`-' |\_) |  |\|  |   |  |          |  |'.'|  | \| |_.'  | /_) |OO  )|       |  |  |(_/|  .     |/(|  '--.
                .-._)   \(|  '---.'  \ |  | |  |   |  |          |  |   |  |  |  .-.  | ||  |`-'| |  .-.  | ,|  |_.'|  |\    |  |  .--'
                \       / |      |    `'  '-'  '   |  |          |  |   |  |  |  | |  |(_'  '--'\ |  | |  |(_|  |   |  | \   |  |  `---.
                 `-----'  `------'      `-----'    `--'          `--'   `--'  `--' `--'   `-----' `--' `--'  `--'   `--'  `--'  `------')EOF");
}

#endif // SLOTMACHINE_H_INCLUDED
