#ifndef CODIGOS_H_INCLUDED
#define CODIGOS_H_INCLUDED

float codigos(char* nome,float din, int jganhos, int npen){
    char cod[20];
    system("cls");

    printf("                         ______\n");
    printf("                  _     ( O  O )     _\n");
    printf("            _____|_|_____( __ )_____|_|_____\n");
    printf("           |                                | \n");
    printf("           |                                | \n");
    printf("           |                                | \n");
    printf("           |           C�digo:              | \n");
    printf("           |                                | \n");
    printf("           |                                | \n");
    printf("           |                                | \n");
    printf("           |________________________________| \n ");
        gotoxy(31,7);
        gets(cod);
        fflush(stdin);
        if(strcmp(strupr(cod),"RELEASE") ==0)
        {
            din=din+100;
            printf("\n\n\n\n\nCodigo v�lido: Ganhou $100");
            printf("\nSaldo:%.2f\n", din);
        }
        else{printf("\n\n\nC�digo inv�lido\n");}

        FILE* nome1;
        nome1 = fopen(nome, "w");
        fprintf(nome1, "%f\n%i\n%i", din, jganhos, npen);
        system("pause");
        system("cls");
        fclose(nome1);

}

#endif // CODIGOS_H_INCLUDED
