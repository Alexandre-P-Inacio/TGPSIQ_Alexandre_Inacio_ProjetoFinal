#ifndef CASINO_H_INCLUDED
#define CASINO_H_INCLUDED

#include "blackjack.h"
#include "roleta.h"



void casino1(char* nome) {
    int e, op;
    float dinheiro;
    int jganhos, npenalizacoes;

        FILE* nome1;
        do {
                system("cls");
        nome1 = fopen(nome, "a+");
        fscanf(nome1, "%f\n%i\n%i", &dinheiro, &jganhos, &npenalizacoes);
        fclose(nome1);
        system("cls");
        textcolor(GREEN);
        printf(R"EOF(
 __   __ __   __ _______ _______ _______ ___ __    _ _______     -------.    ______
|  |_|  |  | |  |       |       |       |   |  |  | |       |  /   o   /|   /\     \
|       |  |_|  |       |   _   |  _____|   |   |_| |   _   | /_______/o|  /o \  o  \
|       |       |      _|  |_|  | |_____|   |       |  | |  | | o     | | /   o\_____\
|       |_     _|     | |       |_____  |   |  _    |  |_|  | |   o   |o/ \o   /o    /
| ||_|| | |   | |     |_|   _   |_____| |   | | |   |       | |     o |/   \ o/  o  /
|_|   |_| |___| |_______|__| |__|_______|___|_|  |__|_______| '-------'     \/____o/
)EOF");

        textcolor(WHITE);
        printf("\n========================================================================================\n");
        printf("Op��o:                                                                         Dinheiro=%.2f\n", dinheiro);
        printf("1-Blackjack\n2-Roleta\n3-Slot Machine\n4-Sair\n");
        gotoxy(7, 11);
        scanf("%i", &op);
        switch (op) {
            case 1:
                blackjack(nome, dinheiro, npenalizacoes, jganhos);
                break;
            case 2:
                roleta(nome, dinheiro, npenalizacoes, jganhos);
                break;
            case 3:
                slotmachin(nome, npenalizacoes, jganhos);
                break;
            case 4: e=3;break;
        }


    } while (e != 3);
}



#endif // CASINO_H_INCLUDED
