#ifndef NAIPES_H_INCLUDED
#define NAIPES_H_INCLUDED

char naipes(carta1,naipe1)
{

    int valor;
    if (naipe1 == '1') {
        printf("\n");
        printf(" ________________________________\n");
        printf("|                                |\n");
        printf("|  %c                             |\n", carta1);
        printf("|               /\\               |\n");
        printf("|              /  \\              |\n");
        printf("|             /    \\             |\n");
        printf("|            /      \\            |\n");
        printf("|           /        \\           |\n");
        printf("|          /          \\          |\n");
        printf("|          \\          /          |\n");
        printf("|           \\        /           |\n");
        printf("|            \\      /            |\n");
        printf("|             \\    /             |\n");
        printf("|              \\  /              |\n");
        printf("|               \\/               |\n");
        printf("|                             %c  |\n", carta1);
        printf("|________________________________|\n");
    } else if (naipe1 == '2') {
        printf("\n");
        printf(" ________________________________\n");
        printf("|                                |\n");
        printf("|  %c                             |\n", carta1);
        printf("|          _                     |\n");
        printf("|       __| |__       / \\        |\n");
        printf("|      |__   __|     |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |       |   |       |\n");
        printf("|        |   |      _|   |_      |\n");
        printf("|        |   |     |__   __|     |\n");
        printf("|         \\ /         |_|        |\n");
        printf("|                                |\n");
        printf("|                            %c   |\n", carta1);
        printf("|________________________________|\n");
    } else if (naipe1 == '3') {
        printf("\n");
        printf(" ________________________________\n");
        printf("|                                |\n");
        printf("|  %c                             |\n", carta1);
        printf("|                                |\n");
        printf("|              / \\               |\n");
        printf("|             /   \\              |\n");
        printf("|            /     \\             |\n");
        printf("|           /       \\            |\n");
        printf("|          /         \\           |\n");
        printf("|         /           \\          |\n");
        printf("|        /             \\         |\n");
        printf("|       (    /|   |\\    )        |\n");
        printf("|        \\__/ |   | \\__/         |\n");
        printf("|             |   |              |\n");
        printf("|             |___|              |\n");
        printf("|                                |\n");
        printf("|                            %c   |\n", carta1);
        printf("|________________________________|\n");
    } else if (naipe1 == '4') {
        printf("\n");
        printf(" ________________________________\n");
        printf("|                                |\n");
        printf("|  %c                             |\n", carta1);
        printf("|          __      __            |\n");
        printf("|         /  \\    /  \\           |\n");
        printf("|        /    \\  /    \\          |\n");
        printf("|       /      \\/      \\         |\n");
        printf("|      /                \\        |\n");
        printf("|     (                  )       |\n");
        printf("|      \\                /        |\n");
        printf("|       \\              /         |\n");
        printf("|        \\            /          |\n");
        printf("|         \\          /           |\n");
        printf("|          \\        /            |\n");
        printf("|           \\      /             |\n");
        printf("|            \\    /              |\n");
        printf("|             \\  /           %c   |\n", carta1);
        printf("|________________________________|\n");
    }

    if (carta1 == '2') {
        valor = 2;
    } else if (carta1 == '3') {
        valor = 3;
    } else if (carta1 == '4') {
        valor = 4;
    } else if (carta1 == '5') {
        valor = 5;
    } else if (carta1 == '6') {
        valor = 6;
    } else if (carta1 == '7') {
        valor = 7;
    } else if (carta1 == '8') {
        valor = 8;
    } else if (carta1 == '9') {
        valor = 9;
    } else if (carta1 == '10') {
        valor = 10;
    } else if (carta1 == 'J') {
        valor = 10;
    } else if (carta1 == 'Q') {
        valor = 10;
    } else if (carta1 == 'K') {
        valor = 10;
    } else if (carta1 == 'A') {
        valor = 10;
    } else {
        printf("Erro\n");
    }
    return valor;
}



#endif // NAIPES_H_INCLUDED
